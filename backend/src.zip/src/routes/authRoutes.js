//const express = require("express");
import express from "express";
import authController from "../controllers/authController";

const router = express.Router();
//const authController = require("../controllers/authController");

router.post("/register", authController.register);
router.post("/login", authController.login);
router.post("/refresh", authController.refreshToken);

//module.exports = router;
export default router;